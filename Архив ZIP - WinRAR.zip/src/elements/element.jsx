function myName(user) {
    return `${user.name} ${user.lastName}`
  }
  const human = {
      name: "Andrew",
      lastName: "Nephew",
  }
  const element = (<div>
    <h1>{myName(human)}</h1>
    </div>)
    export default element;